### Beginner level ###
## Question 1 : Setup a sql3 database called school.db ##
import sqlite3

conn = sqlite3.connect("school.db")
cursor = conn.cursor()
commit = conn.commit()
rollback = conn.rollback()


## Question 2 : Create a table student with column id, name, age, grades and classes ###

student_table = """ CREATE TABLE IF NOT EXISTS student
                    ( ID INTEGER PRIMARY KEY NOT NULL,
                    NAME VARCHAR(20),
                    AGE INTEGER,
                    GRADE CHAR(1),
                    CLASSES VARCHAR(20));"""

classes_table = """ CREATE TABLE IF NOT EXISTS classes
                    ( s_ID INTEGER PRIMARY KEY NOT NULL,
                    NAME VARCHAR(20),
                    class_id integer,
                    CLASSES VARCHAR(20));"""



cursor.execute(student_table)
cursor.execute(classes_table)
##------------- Question 3 : insert data into the table -----------####
student_records = """INSERT OR IGNORE INTO STUDENT VALUES
                    (2501, 'Jacques Leroux', 20, 'A', 'Biology'),
                    (2502, 'Sebastien Lebrin', 21, 'A', 'Math'),
                    (2503, 'Josie Leblond', 22, 'C', 'Physics'),
                    (2504, 'Carole Blouin', 18, 'B', 'Chemistry'),
                    (2505, 'Cynthia Briand', 19, 'A', 'History'),
                    (2506, 'Jean Ferland', 19, 'D', 'Data Structure'),
                    (2507, 'Arthur Delore', 21, 'B', 'Intro to Java'),
                    (2508, 'Ana Delore', 17, 'C', 'Technolie web'),
                    (2509, 'Ryan Brown', 23, 'A', 'Genie Logiciel'),
                    (2510, 'Leslie Burrows', 22, 'B', 'Database') """

classes_record = """INSERT OR IGNORE INTO classes VALUES
                    (2502, 'Sebastien Lebrin', 001, 'Math'),
                    (2503, 'Josie Leblond', 002, 'Physics'),
                    (2504, 'Carole Blouin', 003, 'Chemistry'),
                    (2505, 'Cynthia Briand', 004, 'History'),
                    (2506, 'Jean Ferland', 005, 'Data Structure'),
                    (2507, 'Arthur Delore', 006, 'Intro to Java'),
                    (2508, 'Ana Delore', 007, 'Technolie web'),
                    (2509, 'Ryan Brown', 008, 'Genie Logiciel'),
                    (2510, 'Leslie Burrows', 009, 'Database') """


###-----------Question 4 : retrieve data from the table ----------------####
cursor.execute(student_records)
#cursor.execute(classes_record)

cursor.execute("""select * from student""")
for row in cursor.fetchall():
    if 'A' in row:
        print(row)
#### ----------Question 5 : Update student age ------------#####

print("\n")

cursor.execute("""UPDATE STUDENT SET AGE = 20 WHERE AGE = 19""")
cursor.execute("""select name,age from student""")
for row in cursor.fetchall():
    print(row)
print("\n")

####-----------Question 6 : Delete a student records from the database------------###

cursor.execute("""delete from student where id=2506""")
cursor.execute("""select name from student""")
for row in cursor.fetchall():
    print(row)
####-------------Question 7 : Use pandas to load the mysql database into panda dataframe----------#####
import pandas as pd

df = pd.read_sql("""select * from student""",conn)
print(df)
print("\n")

#df.set_index('ID',inplace=True)
print(df)

####----------Question 8 : Use panda to insert data in the database. Use the to_sql method.##

df1=pd.DataFrame(columns=df.columns)
row = [2511,'Mark Carney', 59, 'A+', 'International Politics']

#df1.rename(columns={df.columns[0]:'ID'}, inplace=True)
df1.loc[0]=row

print("\n")
print(df1)

#df1.to_sql('student',conn, if_exists='append',index=False) statement to insert the dataframe into to a row

print("\n")

cursor.execute("""select * from student""")
for row in cursor.fetchall():
    print(row)
####---------------Question 9 : Write a functions that accept student data as entries an insert them into a DataBase------------###
####---------------Question 10 : Modify the function to use parameterized queries to prevent SQL injections.--------####
def addToDB(s_id, name, age, grade, classes):
    # Ensure all values are strings where needed
    name = str(name)
    grade = str(grade)
    classes = str(classes)

    # Use parameterized query — prevents SQL injection and handles quotes properly
    new_row = """
        INSERT OR IGNORE INTO STUDENT 
        VALUES (?, ?, ?, ?, ?)
    """
    
    cursor.execute(new_row, (s_id, name, age, grade, classes))
    conn.commit()  # Make sure to commit if you're doing inserts


addToDB(2601,'Dudley Orestil', 41, 'D-', 'Assembly')
cursor.execute("""select * from student""")
for row in cursor.fetchall():
    print(row)

####---------Intermediate Level------------------------####
####----------------Question 11: Transaction management --> Implements transactions handling with commits and rollback functionnalities-------#####

#### INSERT, UPDATE, DELETE  or any other changes to the database are considered transactions. When they are executed, it is good practice to throw a 'commit' command to make sure that the changed are saved to the database or execute a 'rollback' to go back to the previous version in case an error was raise.


new_entry = """ INSERT OR IGNORE INTO STUDENT VALUES
(2700,'Tony Stark', 52, 'A+', 'Robotics')"""

print("\n")

try:
    cursor.execute(new_entry)
    cursor.execute("""select * from student where id = 2700""")
    print(cursor.fetchall())
    raise ValueError("Something went wrong!") # Just a test where we raise an error on purpose to force the rollback
    commit
except Exception as e:
    print("Rolling back because of ", e)
    rollback
#####----------------Question 12 : Complex queries  --> Fetch student where age is greater 18 and grade is greater than 90(A)---------###

print("\n")

query = """ select name from student where grades like 'A' and age > 18 """

try:
    cursor.execute(query)
    for i in cursor.fetchall():
        print(i) 
    commit
except (ValueError, EOFError):
    print("Something unexpected happened...")
    print("Changed cancelled...rolling back to previous version.")


print("\n")

###------------------------------Question 13  'Join operations' : Create a second table with classes with class_id, class_name and student_id. Write a query fetch all student with their respective class name.


join_operation = """select classes.name,student.classes 
                    from student cross join classes on classes.name = student.name"""

cursor.execute(join_operation)

for i in cursor.fetchall():
    print(i)

print('\n')

###------------------------------Question 14 'Migration' : Alter one of the database by adding a column

alter_table = """ alter table classes add column grade char(1)"""
cursor.execute(alter_table)

update_grade = """ UPDATE classes SET grade = 'A' """

cursor.execute(update_grade)
cursor.execute("""select * from classes""")
for i in cursor.fetchall():
    print(i)

###------------------------------Question 15 'Batch insertion' : Write a querie to enter multiple record in the database in a single transaction.

insert_query = """
INSERT OR IGNORE INTO classes (s_ID, NAME, class_id, CLASSES, grade)
VALUES (?, ?, ?, ?, ?)
"""

records = [
    (1001, 'Alice Smith', 201, 'Mathematics', 'A'),
    (1002, 'Bob Johnson', 202, 'Physics', 'B'),
    (1003, 'Cathy Brown', 203, 'Biology', 'A'),
    (1004, 'David Lee', 204, 'Chemistry', 'C'),
    (1005, 'Eva White', 205, 'History', 'B')
]

cursor.executemany(insert_query, records)
conn.commit()


for i in cursor.fetchall():
    print(i)
print("\n")

###------------------------------Question 16 : Use SQL to find the average grade and total number of students.

count_grade = """ SELECT  grade, COUNT(grade) FROM classes GROUP BY grade"""
cursor.execute(count_grade)
for i in cursor.fetchall():
    print(i)
print("\n")

###------------------------------Question 17 : Create and query a view that shows the number of student in each grade

view_by_grade = """ CREATE VIEW IF NOT EXISTS [Student_by_grades] AS
                   SELECT grade, COUNT(grade) FROM classes GROUP BY grade """
cursor.execute(view_by_grade)
cursor.execute("SELECT * FROM [Student_by_grades]")
for i in cursor.fetchall():
    print(i)
print("\n")

