### Part 3 of the exercices
### Advanced level : Question 21 to 30

#list of import
import sqlite3
import pandas as pd
import plotly.express as px
import shutil

#Connecting to the database
conn = sqlite3.connect('school.db')
cursor = conn.cursor()

conn2 = sqlite3.connect('copy.db')
cursor2 = conn2.cursor()

###------------------------------Question 21 Simulates stored procedures using python that encapsulate complex SQL queries

#cursor.execute( """ CREATE PROCEDURE get_all_student()
#                    BEGIN
#                    SELECT * FROM student;
#                    END 
#               """)
#sqlite3 doesnt support stored procedure but this would be the syntax to create one using MySQL or pymysql


###------------------------------Question 22 Perform a complex join across multiple table to produce a comprehensive dataset

cursor.execute("select name from sqlite_master where type = 'table'")
for i in cursor.fetchall():
    print(i)

### -----------------Creatind dataframe of the tables for future exercices---------####
df_student = pd.read_sql_query("select * from student", conn)
df_classes = pd.read_sql_query("select * from classes",conn)
df_classes_copy = pd.read_sql_query("select * from classes_copy",conn)


df_student.reset_index(drop = True, inplace = True)
df_classes.reset_index(drop = True, inplace = True)
df_classes_copy.reset_index(drop = True, inplace = True)
###----------------------End of those statement-------------------------------------####
print(df_student)
print(df_classes)
df_join = pd.read_sql_query("SELECT student.name, student.classes, classes.name from STUDENT LEFT JOIN classes where student.name = classes.name", conn)

print(df_join)
#conn.close()
###------------------------------Question 23 : Write a script to save the entire python database to another file.----------------###
###------------------------------Question 24 : Write a script to restore the entire python database from another file.----------------###

#with open('school.db', 'rb') as original, open('copy.db', 'wb') as copy:
#    copy.write(original.readline())
#important to note that you have to use rb or wb when reading a binary file (database, code, etc.)
#print("\n")
print("This is a copy")
cursor2.execute("select *from student")
for i in cursor2.fetchall():
    print(i)
print("End of the copy")
print("\n")

#This is a more concise way of copying any file
#shutil.copyfile('school.db','copy.db')

###------------------------------ Question 25 : Use indexes on the student table and show performance improvements.
### index speed up reading but slows down writing(INSERT, UPDATE, ALTER, etc.)
### Only use indexes on column you have to read often
### index are use on an attribute of a table to speed up accesses

#cursor.execute("CREATE INDEX idx_name ON student(NAME)")
cursor.execute("SELECT name FROM student")
for i in cursor.fetchall():
    print(i)
print("\n")
###------------------------------Question 26 : Perform a full text search across the student name
#cursor.execute("ALTER TABLE student FULLTEXT(name)")
#cursor.execute("SELECT name FROM student WHERE MATCH(name) AGAINST('Alice')")
#for i in cursor.fetchall():
#    print(i)
#sqlite3 doesnt support FULLTEXT but this is how it would be done

###------------------------------Question 27 : Write a query to paginate result, 10 at a time.

print("\n")
