#Second part of the exercices

#list of import
import sqlite3
import pandas as pd
import plotly.express as px

#Connecting to the database
conn = sqlite3.connect('school.db')
cursor = conn.cursor()

#test code to see if the connection to the database worked properly
"""
test_querie = " select *from student " 
test_querie2 = " select * from classes "

cursor.execute(test_querie)

for i in cursor.fetchall():
    print(i)
print("\n")


cursor.execute(test_querie2)

for i in cursor.fetchall():
    print(i)
print("\n")
"""
#Just a command to print carriage return without having to rewrite the print statement
retour=print("\n")

#Create a copy of the table classes
classes_table = """ CREATE TABLE IF NOT EXISTS classes_copy
                    ( s_ID INTEGER PRIMARY KEY NOT NULL,
                    NAME VARCHAR(20),
                    class_id integer,
                    CLASSES VARCHAR(20));"""


cursor.execute(classes_table)

#alter_table = """ alter table classes_copy add column grade char(1)"""
#cursor.execute(alter_table)

#update_grade = """ UPDATE classes_copy SET grade = 'A' """

#cursor.execute(update_grade)

###------------------------------Question 18 : Use pandas to import the database to a csv file------------------


df = pd.read_sql_query("select *from classes",conn)
df.to_csv("classes.csv", index=False)

print("\n")
print(df)
print("\n")

###------------------------------Question 19 : Load data to a table using the csv file
df2 = pd.read_csv("classes.csv")
print(df2)

print("\n")

df2.to_sql("classes_copy",con=conn, if_exists='replace',index=False)
cursor.execute("select *from classes_copy")

for i in cursor.fetchall():
    print(i)
print("\n")

###------------------------------Question 20 : Use pandas and matplotlib to trace the distribution of grade among students

df2['grade']=df2['grade'].replace({'A':90,'B':80,'C':70})
print(df2)

#creating a line chart
fig = px.line(df2, x='NAME', y='grade', title = 'Distribution of grade among student')
fig.write_html('Grades distribution among student.html')



