#include <string>
#include <fstream>
#include <iostream>

using namespace std;


int main(){
	//1. Saisir le nom d'utilisateur
	
	string user;
	string pass;
	bool userValidation = false;
	bool passValidation = false;
	string info;
	string buffer;

	cout << "Veuillez entrez le nom d'utilisateur et le mot de passe."<<endl;
	cin >> user >> pass;

	//2. Créer un objet pour lire dans un fichier
	
	ifstream loginInfo("login.txt");

	while(getline(loginInfo,info)){
		if(info.empty()){
			continue;
		}
		buffer+=info;
	}

	loginInfo.close();

	//3. Créer une logique pour récupérer le nom d'utilisateur et le mot de passe

	int pos = buffer.find("pass");
	string userVal = buffer.substr(0,pos);
	pos = userVal.find("=");
	userVal = userVal.substr(pos+2,userVal.length()-pos);

  	
	int pos2 = buffer.find("pass");
	string passVal = buffer.substr(pos2,buffer.length()-pos2);
	pos2 = passVal.find("=");
	passVal = passVal.substr(pos+2,passVal.length()-pos2);





	//4. Le comparer au nom d'utilisateur recherché
	if(userVal == user){
		userValidation = true;
	}
	if(passVal == pass){
		passValidation = true;
	}


	return EXIT_SUCCESS;
}
