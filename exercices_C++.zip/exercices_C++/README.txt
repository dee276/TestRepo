Ce dossier contient une classe rectangle pour tester les théories de la programmation orientée objet en c++.

Il contient également une implémentation d'un test de login backend où l'utilisateur saisi un nom et un mot de passe et il est comparé à celui dans le fichier "login".