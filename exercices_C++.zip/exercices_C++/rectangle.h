#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <iostream>

class rectangle {
public:
    rectangle(float lon_, float la_);
    
    void updateSurface();
    void updatePerimetre();

    void setLon(float lon_);
    void setLa(float la_);

    float getLon() const;
    float getLa() const;
    float getSurface() const;
    float getPerimetre() const;

private:
    float longueur;
    float largeur;
    float surface;
    float perimetre;
};

std::ostream& operator<<(std::ostream& out, const rectangle& r);

#endif

