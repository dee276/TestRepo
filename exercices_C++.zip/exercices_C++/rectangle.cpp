#include "rectangle.h"

using namespace std;

rectangle::rectangle(float lon_, float la_) {
    longueur = lon_;
    largeur = la_;
    updateSurface();
    updatePerimetre();
}

void rectangle::updateSurface() {
    surface = longueur * largeur;
}

void rectangle::updatePerimetre() {
    perimetre = 2 * (longueur + largeur);
}

void rectangle::setLon(float lon_) {
    longueur = lon_;
    updateSurface();
    updatePerimetre();
}

void rectangle::setLa(float la_) {
    largeur = la_;
    updateSurface();
    updatePerimetre();
}

float rectangle::getLon() const {
    return longueur;
}

float rectangle::getLa() const {
    return largeur;
}

float rectangle::getSurface() const {
    return surface;
}

float rectangle::getPerimetre() const {
    return perimetre;
}

ostream& operator<<(ostream& out, const rectangle& r) {
    out << "Largeur = " << r.getLa() << endl
        << "Longueur = " << r.getLon() << endl
        << "Surface = " << r.getSurface() << endl
        << "Périmètre = " << r.getPerimetre() << endl;
    return out;
}

