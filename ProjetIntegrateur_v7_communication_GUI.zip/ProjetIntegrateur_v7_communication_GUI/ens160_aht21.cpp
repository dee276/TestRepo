#include "ens160_aht21.h"

#define ENS160_I2C_ADDRESS  0x53
#define ENS160_PART_ID_REG  0x00
#define ENS160_STATUS_REG   0x20
#define ENS160_DATA_REG     0x22
#define ENS160_ENV_DATA_REG 0x24
#define ENS160_MODE_REG     0x10

Adafruit_AHTX0 aht;

void lireENS160_AHT21() {
  float temp, hum;
  if (lireTemperatureEtHumidite(temp, hum)) {
    Serial.print("--> Température: "); Serial.print(temp); Serial.println(" °C");
    Serial.print("--> Humidité: "); Serial.print(hum); Serial.println(" %");

    envoyerConditionsEnv(temp, hum);
    mesurerEtAfficherGaz();
  } else {
    Serial.println("[WARN] AHT21 non disponible !");
  }

  delay(5000);
}

bool lireTemperatureEtHumidite(float& tempC, float& humPct) {
  sensors_event_t humidity, temp;
  if (!aht.getEvent(&humidity, &temp)) return false;
  tempC = temp.temperature;
  humPct = humidity.relative_humidity;
  return true;
}

void envoyerConditionsEnv(float temperature, float humidity) {
  uint16_t tempData = (uint16_t)((temperature + 273.15f) * 64.0f);
  uint16_t humData  = (uint16_t)(humidity * 512.0f);
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_ENV_DATA_REG);
  Wire.write(tempData & 0xFF); Wire.write((tempData >> 8) & 0xFF);
  Wire.write(humData & 0xFF);  Wire.write((humData >> 8) & 0xFF);
  Wire.endTransmission();
  Serial.println("[OK] Données ENV envoyées.");
}

void mesurerEtAfficherGaz() {
  forceENS160Measurement();
  uint8_t data[4];
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_DATA_REG);
  if (Wire.endTransmission() != 0 || Wire.requestFrom(ENS160_I2C_ADDRESS, 4) != 4) {
    Serial.println("[WARN] Aucune donnée disponible !");
    return;
  }
  data[0] = Wire.read(); data[1] = Wire.read();
  data[2] = Wire.read(); data[3] = Wire.read();
  uint16_t tvoc = data[0] | (data[1] << 8);
  uint16_t eco2 = data[2] | (data[3] << 8);
  Serial.print("[OK] eCO2: "); Serial.print(eco2); Serial.println(" ppm");
  Serial.print("[OK] TVOC: "); Serial.print(tvoc); Serial.println(" ppb");
}

void forceENS160Measurement() {
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_MODE_REG);
  Wire.write(0x02);
  Wire.endTransmission();
  Serial.println("--> Mesure ENS160 lancée.");
  delay(500);
}

uint16_t getPartID() {
  uint8_t data[2];
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_PART_ID_REG);
  if (Wire.endTransmission() != 0) return 0xFFFF;
  Wire.requestFrom(ENS160_I2C_ADDRESS, 2);
  data[0] = Wire.read(); data[1] = Wire.read();
  return (data[1] << 8) | data[0];
}

uint8_t readSensorStatus() {
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_STATUS_REG);
  if (Wire.endTransmission() != 0) return 0xFF;
  Wire.requestFrom(ENS160_I2C_ADDRESS, 1);
  return Wire.read();
}

void setENS160Mode(uint8_t mode) {
  Wire.beginTransmission(ENS160_I2C_ADDRESS);
  Wire.write(ENS160_MODE_REG);
  Wire.write(mode);
  Wire.endTransmission();
  Serial.print("[AUTO] Mode ENS160: ");
  Serial.println(mode, HEX);
}

void initialiserENS160() {
  uint16_t partID = getPartID();
  Serial.print("[ID] ENS160 ID: 0x");
  Serial.println(partID, HEX);
  if (partID != 0x0160 && partID != 0x0161) {
    Serial.println("[FAIL] ENS160 non détecté !");
    return;
  }
  Serial.println("[OK] ENS160 détecté.");
  uint8_t status = readSensorStatus();
  Serial.print("--> Statut ENS160: ");
  Serial.println(status, HEX);
  setENS160Mode(0x02);
}

void initialiserAHT21() {
  Serial.println("[Searching...] Init AHT21...");
  if (!aht.begin()) {
    Serial.println("[FAIL] AHT21 non détecté !");
  } else {
    Serial.println("[OK] AHT21 détecté.");
  }
}
