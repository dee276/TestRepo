#ifndef ENS160_AHT21_H
#define ENS160_AHT21_H

#include <Wire.h>
#include <Adafruit_AHTX0.h>

extern Adafruit_AHTX0 aht;

void lireENS160_AHT21();
uint16_t getPartID();
uint8_t readSensorStatus();
void setENS160Mode(uint8_t mode);
void initialiserENS160();
void initialiserAHT21();

// Fonctions internes utilisées dans le .cpp
bool lireTemperatureEtHumidite(float& tempC, float& humPct);
void envoyerConditionsEnv(float temperature, float humidity);
void mesurerEtAfficherGaz();
void forceENS160Measurement();

#endif
