public class rectangle extends Forme2D{
	private double longueur;
	private double largeur;

	public rectangle(double larg, double lng){
		this.longueur = lng;
		this.largeur = larg;
	}

	@Override
        double aire(){
	
         return (Math.round(longueur*largeur*100)/100.0);

	}

	@Override
	public String toString(){
		return " Cette forme est un rectangle de largeur: "+this.largeur+", de longueur: "+this.longueur+" et son aire est: "+aire();
	}
}
