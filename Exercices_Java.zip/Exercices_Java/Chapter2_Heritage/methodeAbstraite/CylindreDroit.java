public class CylindreDroit extends Forme3D{

	private Forme2D base;
	private double hauteur;

	public CylindreDroit(Forme2D forme, double hauteur){
		this.base = forme;
		this.hauteur = hauteur;

	}

	@Override
	double volume(){

		return this.base.aire()*this.hauteur;
	}

	@Override
	public String toString(){
		return " Cette forme est une cylindre droit. Sa base est un: "+this.base+" et son volume est: "+volume();
	}
}
