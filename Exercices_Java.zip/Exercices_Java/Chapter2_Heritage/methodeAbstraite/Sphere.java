public class Sphere extends Forme3D{

	private double rayon;

	public Sphere(double r){

		this.rayon = r;
	}

	@Override
	double volume(){
		return (Math.round(Math.pow(this.rayon,3))*100*3.1416)/100.0;
	}
	
	@Override
	public String toString(){
		return " Ce forme 3D est une sphere. Elle a un rayon de: "+this.rayon+" et un volume de: "+volume();
	}
}
