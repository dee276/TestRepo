abstract class Forme3D{

	abstract double volume();

}
