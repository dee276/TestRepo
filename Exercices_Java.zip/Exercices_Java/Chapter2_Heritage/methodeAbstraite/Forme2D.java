abstract class Forme2D{

	//méthode abstraite pour calculer l'aire
	abstract double aire(); 

}
