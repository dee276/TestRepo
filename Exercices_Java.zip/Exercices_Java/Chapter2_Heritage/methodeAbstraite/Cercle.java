public class Cercle extends Forme2D{
	
	//attribut pour le calcul du rayon
	private double rayon;
	private double aire;

	public Cercle(double rayon){
		this.rayon = rayon;
		this.aire = aire();
	}


        @Override
	double aire(){
		return (Math.round((this.rayon*this.rayon*3.1416)*100)/100);
	}

	@Override
	public String toString(){
		return "Cette forme est un cercle \n et elle a un rayon de : "+this.rayon+" et son aire est de "+aire();}
}
