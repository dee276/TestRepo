public class principal{

	public static void main(String arg[]){

		Cercle cercle1 = new Cercle(3);
		rectangle rectangle1 = new rectangle(4,8);
		Sphere sphere1 = new Sphere(5);
		CylindreDroit cd = new CylindreDroit(cercle1, 10);
		CylindreDroit cd2 = new CylindreDroit(rectangle1, 10);
		
		System.out.println("");
		System.out.println(sphere1);

		System.out.println(rectangle1);
		System.out.println("");
		System.out.println(cercle1);

		System.out.println("");
		System.out.println(cd);
		System.out.println("");
		System.out.println(cd2);

	}
}
