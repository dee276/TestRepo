package Produit
public Class Produit{

	public Produit(){
		this.nom = _nom;
		this.prix = _prix;
	}
	
	private String nom;
	private double prix;
}