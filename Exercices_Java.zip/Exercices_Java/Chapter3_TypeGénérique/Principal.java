public class Principal {

    public static void main(String[] args) {
        @SuppressWarnings("unchecked")
        PeutEtre<Integer>[] tableau = (PeutEtre<Integer>[]) new PeutEtre[10];

        // On remplit le tableau avec les entiers de 0 à 9
        for (int i = 0; i < 10; i++) {
            tableau[i] = new QQChose<>(i);
        }

        PeutEtre<Integer> val1 = new QQChose<>(3);
        PeutEtre<Integer> val2 = new QQChose<>(25);

        System.out.println(trouverElement(tableau, val1));
        System.out.println(trouverElement(tableau, val2));
    }

    public static <T> PeutEtre<Integer> trouverElement(PeutEtre<T>[] a_tableau, PeutEtre<T> a_element) {
        for (int i = 0; i < a_tableau.length; i++) {
            try {
                if (a_tableau[i].qQChose().equals(a_element.qQChose())) {
                    return new QQChose<>(i);
                }
            } catch (ARien e) {
                // au cas où l’élément est un Rien
            }
        }
        return new Rien<>();
    }
}

