public class ARien extends Exception {
	public ARien(){
		super();
	}
	public ARien( String message){
		super( message );
	}
}
