public class TestMRand {

    public static void testerGenerateur(MRand generateur, int iterations) {
        int[] frequence = new int[100]; // si borneSuperieure = 100
        for (int i = 0; i < iterations; i++) {
            int val = generateur.get();
            frequence[val]++;
        }

        for (int i = 0; i < frequence.length; i++) {
            System.out.printf("%2d: %d\n", i, frequence[i]);
        }
    }

    public static void main(String[] args) {
        // Exemple avec valeurs proposées
        long M = 0x0100_0000_0000L;
        long A = 0x5DEECE66DL;
        long C = 11L;

        MRand mrand = new MRand(100, 0, M, A, C);
        testerGenerateur(mrand, 1_000_000);
    }
}

