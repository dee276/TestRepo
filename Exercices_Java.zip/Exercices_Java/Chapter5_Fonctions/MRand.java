import java.util.function.Supplier;
import java.util.Arrays;

public class MRand implements Supplier <Integer>{
	

	// Constantes du générateur
	protected static final long M;
	protected static final long A;
	protected static final long C;
	protected static final long MASK = 0x0000_7FFF_FFFF_0000L;
	protected static final int DEC = 16;

	private int borneSuperieure;
	private long x;

	public MRand(){
		this(Integer.MAX_VALUE);
	}

	public MRand(int borneSuperieure){
		this.borneSuperieure = borneSuperieure;
		this.x = 0;
	}

	public MRand(long borneSuperieure, long seed, long M, long A, long C) {
        
	this.borneSuperieure = borneSuperieure;
        this.x = seed;
        this.M = M;
        this.A = A;
        this.C = C;
        
	}


	@Override
	public Integer get(){
		x = (A*(x+C))%M;
		return (int)(((x & MASK) >> DEC) % borneSuperieure);
	}

	public static void testerGenerateur(Supplier <Integer> generateur){
		int borne = 100;
		int[] occurrences = new int[borne];
		int iterations = 1_000_000;

		for (int i = 0; i < iterations; i++){
			int valeur = generateur.get();
			if (valeur >= 0 && valeur < borne){
				occurrences[valeur]++;
			}
		}
		
		for (int i = 0; i < borne; i++){
			System.out.printf("Valeur %d : %d occurrences\n", i, occurrences[i]);
		}
	}

	public static void main(String[] args){
		MRand gen = new MRand(100);
		testerGenerateur(gen);
	}
}
