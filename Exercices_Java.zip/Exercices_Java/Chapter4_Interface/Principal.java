import java.util.ArrayList; //import the ArrayList class

public class Principal{
	public static void main(String args[]){
		NDouble val = new NDouble (10);
		Fraction rat1 = new Fraction(1,4);
		Fraction rat2 = new Fraction(2,4);
		System.out.println(rat1.add(rat2));
		System.out.println(val);
		System.out.println(rat1);
		System.out.println(rat2);
		ArrayList <Fraction> set = new ArrayList<>();
		for(int i = 0; i<10; i++){
			set.add(new Fraction(i,i*2));
		}
		System.out.println(set);
	}
}
