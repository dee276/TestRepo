public interface Nombre <N> {
	N add( N x);
	N sub( N x);
	N mul( N x);
	N div( N x);
}
