public class NDouble implements Nombre <NDouble>{
	private double var;

	public NDouble(double val){
		this.var = val;
	}

	@Override
	public NDouble add( NDouble x){
		return new NDouble(this.var + x.var);
	}

	@Override
	public NDouble sub( NDouble x){
		return new NDouble(this.var - x.var);
	}
	
	@Override
	public NDouble mul( NDouble x){
		return new NDouble(this.var * x.var);
	}

	@Override
	public NDouble div( NDouble x){
		return new NDouble((this.var)/x.var);
	}

	@Override
	public String toString(){
		return "This object is a NDouble and has a value of :"+this.var+".";
	}
}


