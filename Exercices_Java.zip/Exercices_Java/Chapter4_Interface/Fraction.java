public class Fraction implements Nombre <Fraction>{
	private double num;
	private double den;

	public Fraction(double n, double d){
		this.num = n;
		this.den = d;
	}

	@Override
	public Fraction add(Fraction n){
		 return new Fraction(((this.num*n.den)+(this.den*n.num)),(this.den*n.den));
	}
	@Override
	public Fraction sub(Fraction n){
		return new Fraction(((this.num*n.den)-(this.den*n.num)),(this.den*n.den));
	}
	@Override
	public Fraction mul(Fraction n){
		return new Fraction((this.num*n.num),(this.den*n.den));
	}
	@Override
	public Fraction div(Fraction n){
		return new Fraction((this.num*n.den),(this.den*n.num));
	}
	@Override
	public String toString(){
		return "This object is a Fraction. Its value is :"+this.num+"/"+this.den+".";
	}

}
