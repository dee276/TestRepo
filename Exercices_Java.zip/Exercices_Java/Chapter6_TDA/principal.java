import java.util.ArrayList;

public class principal{
	public static void main(String [] args){

          Dequeue <Integer> var_a = new Dequeue<>(); 	
	  System.out.println(var_a.addElement(10));
	  System.out.println(var_a.emptyDequeue());


	}
}
