public class Dequeue<T>{
	//attribute of the abstract list
	private T[] tab;
	private int nb_items;
	private int size;
	
	//Constructors of the class
	@SuppressWarnings("unchecked")
	public Dequeue(){
		tab = (T[]) new Object[10];
		size = 10;
		nb_items = 0;
	}

	@SuppressWarnings("unchecked")
	public Dequeue(int size_){
		tab = (T[]) new Object[size_];
		size = size_;
		nb_items = 0;
	}

	//Method to add an element to the list
	public boolean addElement(T element){
		int j=0;
		if(nb_items==tab.length){
		 	T[] tab_temp = (T[])new Object[nb_items*2];
			for(int i=0;i<tab.length;i++){
				tab_temp[i]=tab[i];
				j=i;
			}
			tab=tab_temp;
			tab[j+1]=element;
			size = nb_items*2;
			nb_items=nb_items+1;
			return nb_items!=0;
		}
		else{
			tab[nb_items+1]=element;
			size=nb_items+1;
			nb_items=nb_items+1;
			return nb_items!=0;
		}
	}

	//Method to empty the list
	public boolean emptyDequeue(){
		T[] tab_temp = (T[])new Object[size];
		tab = tab_temp;
		return nb_items==0;
	}


}
